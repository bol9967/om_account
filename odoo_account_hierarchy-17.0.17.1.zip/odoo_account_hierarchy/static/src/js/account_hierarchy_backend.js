/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { Component, onWillStart, onMounted, useState, useRef } from "@odoo/owl";
import { download } from "@web/core/network/download";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { Layout } from "@web/search/layout";
import { useSetupAction } from "@web/webclient/actions/action_hook";

function processLine(line) {
    return { ...line, lines: [], isFolded: true };
}

export class AccountHierarchyReport extends Component {
    static template = "odoo_account_hierarchy.AccountHierarchyReport";
    static components = { Layout };

    setup() {
        this.actionService = useService("action");
        this.action = useService("action");
        this.orm = useService("orm");
        this.rpc = useService("rpc");
        this.user = useService("user");

        this.lineRef = useRef("line");

        onWillStart(this.onWillStart);
        onMounted(this.onMounted);
        useSetupAction({
            getLocalState: () => ({
                lines: [...this.state.lines],
            }),
        });

        this.state = useState({
            lines: this.props.state?.lines || [],
        });

        const { active_id, active_model, auto_unfold, date_from, date_to, state, company_id, company_name, url } = this.props.action.context;
        this.company_name  = company_name;
        this.controllerUrl = url;

        this.context = this.props.action.context || {};
        Object.assign(this.context, {
            active_id: active_id || this.props.action.params.active_id,
            auto_unfold: auto_unfold || false,
            model: active_model || false,
        });

        this.display = {
            controlPanel: {},
            searchPanel: false,
        };
    }
    async onWillStart() {
        if (!this.state.lines.length) {
            const mainLines = await this.orm.call("account.hierarchy", "get_main_lines", [
                this.context,
            ]);
            this.state.lines = mainLines.map(processLine);
        }
    }
    async onMounted() {
        if (this.context.auto_unfold) {                         
            this.onExpandHierarchy();            
        }
    }
    onCLickOpenAccount(line) {
        console.log("onCLickOpenLot",line)
        this.actionService.doAction({
            type: "ir.actions.act_window",
            res_model: 'account.account',
            res_id: line.rec_id,
            views: [[false, "form"]],
            target: "current",
        });
    }

    onClickPrint() {
        var self = this;
        const url = self.controllerUrl
            .replace("active_id", self.context.active_id)
            .replace("active_model", 'account.hierarchy')
            .replace("output_report_format", "pdf");
        
        download({
            data: {},
            url,
        });
    }

    onClickXls(){
        var self = this;
        const url = self.controllerUrl
            .replace("active_id", self.context.active_id)
            .replace("active_model", 'account.hierarchy')
            .replace("output_report_format", "xls");
        
        download({
            data: {},
            url,
        });
    }

    async boundLink(line) {         
        var line_id = line.id;
        var active_id = line.active_id;
        const Lines = await this.orm.call("account.hierarchy", "get_child_ids", [active_id, line_id], {})
        if (Lines){
            this.action.doAction({
                type: 'ir.actions.act_window',
                name: _t('Journal Items'),
                target: 'current',
                res_model: 'account.move.line',
                domain: Lines,
                views: [[false, 'list'], [false, 'form']],
                view_mode: "list",
                target: 'current'
            });
        }
    }

    async toggleLine(line) {
        line.isFolded = !line.isFolded;
        var row_level = line.level;
        if (!line.lines.length) {
            line.lines = (
                await this.orm.call("account.hierarchy", "get_lines", [line.id], {
                    active_id: line.active_id,
                    level:parseInt(row_level) + 1 || 1,
                })
            ).map(processLine);
        }
    }
    
    onExpandHierarchy(){
        var self = this;
        const lines = $(self.lineRef.el).find('tr');
        $.each(lines.find('.fa-caret-right'), function () { 
            var $CurretElement = $(this).parents('tr');
            var id = $CurretElement.data('id');
            self.autounfold(id);
        });
    }

    onCollapseHierarchy(){
        var self = this;
        const lines = $(self.lineRef.el).find('tr');
        $.each(lines.find('.fa-caret-down'), function () { 
            var $CurretElement = $(this).parents('tr');
            var id = $CurretElement.data('id');
            self.autofold(id);
        });
    }
    async autounfold(id){
        var self = this;
        const line = self.getLineById(id, self.state.lines);
        const hasLines = await this.orm.call("account.hierarchy", "get_lines", [line.id], {
            active_id: line.active_id,
            level:parseInt(line.level) + 1 || 1,
        })
        if (hasLines){
            line.lines = hasLines.map(processLine);
            self.toggleLine(line);
        }
        if (line.lines) {
            for (let l of line.lines) {
                self.autounfold(l.id)
            }
        }
    }
    async autofold(id) {
        var self = this;
        const line = self.getLineById(id, self.state.lines);
        if (line.lines){
            line.isFolded = false;
            self.toggleLine(line);
        }
        if (line.lines) {
            for (let l of line.lines) {
                self.autofold(l.id)
            }
        }
    }
    
    getLineById(id, lines) {
        var self = this;
        for (let line of lines) {
            if (line.id === id) {
                return line
            }
            if (line.lines) {
                const idFoundInChildren = self.getLineById(id, line.lines)
                if (idFoundInChildren !== null) {
                    return idFoundInChildren
                }
            }
        }
        return null
    }
    
}

registry.category("actions").add("account_hierarchy", AccountHierarchyReport);
