Parent Account / Chart of Accounts Hierarchy / Chart of Account Hierarchy / Account Hierarchy
=============================================================================================
- The hierarchy of accounts defines how accounts are related to one another. 
    This module will visually add the parent id of each account and build a tree structure relationship between accounts.
Installation
============
- Copy account_parent_hierarchy module to addons folder
- Install the module normally like other modules.