# -*- coding: utf-8 -*-
from odoo import api, fields, models


class RequisitionConfirmWizard(models.TransientModel):
    """Confirmation wizard for requisition for pick ticket cases"""
    _name = 'requisition.confirm.wizard'
    _description = 'Requisition Confirm Wizard'

    requisition_id = fields.Many2one('employee.purchase.requisition',
                                     'Purchase Requisition')
    requisition_line_ids = fields.One2many('requisition.wizard.line',
                                           'requisition_confirm_wizard_id',
                                           string="Requisition Lines")

    def action_confirm(self):
        """action confirm of the wizard for confirming the PR"""
        for line in self.requisition_line_ids:
            if line.exact_requisition_line_id:
                line.exact_requisition_line_id.quantity = line.quantity
                line.exact_requisition_line_id.requisition_type = line.requisition_type
                line.exact_requisition_line_id.message = line.message
            else:
                self.requisition_id.sudo().write({
                    'requisition_order_ids': [fields.Command.create({
                        'product_id': line.product_id.id,
                        'requisition_type': line.requisition_type,
                        'quantity': line.quantity,
                        'requisition_product_id': self.requisition_id.id,
                        'message': line.message,
                    })]
                })
        self.requisition_id.write({'state': 'waiting_department_approval'})
        self.requisition_id.confirm_id = self.env.uid
        self.requisition_id.confirmed_date = fields.Date.today()


class RequisitionLineWizard(models.TransientModel):
    """Confirmation line for requisition wizard"""
    _name = 'requisition.wizard.line'
    _description = 'Requisition Wizard Line'

    requisition_confirm_wizard_id = fields.Many2one(
        'requisition.confirm.wizard')
    product_id = fields.Many2one('product.product', 'Product')
    quantity = fields.Float('Quantity', default=0.0)
    uom_id = fields.Many2one('uom.uom', 'Uom')
    requisition_type = fields.Selection(
        string='Requisition Type',
        selection=[
            ('purchase_order', 'Purchase Tender'),
            ('internal_transfer', 'Internal Transfer'),
            ('pick_ticket', 'Pick Ticket'),
        ], help='Type of requisition')
    exact_requisition_line_id = fields.Many2one('requisition.order',
                                                'Exact Requisition Line')
    exact_requisition_id = fields.Many2one('employee.purchase.requisition',
                                           'Exact Requisition')
    message = fields.Char('Message')

    @api.onchange('quantity')
    def _onchange_quantity(self):
        self.ensure_one()
        self.message = ''
