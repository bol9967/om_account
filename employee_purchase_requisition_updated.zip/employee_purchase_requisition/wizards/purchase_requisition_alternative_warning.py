# -*- coding: utf-8 -*-
from odoo import models


class PurchaseRequisitionAlternativeWarning(models.TransientModel):
    """Purchase Requisition alternative warning inheritance"""
    _inherit = 'purchase.requisition.alternative.warning'

    def action_cancel_alternative_notify(self):
        """cancelling the alternative POs along with informing the vendor"""
        self.alternative_po_ids.filtered(
            lambda po: po.state in ['draft', 'sent', 'to approve']
                       and po.id not in self.po_ids.ids
        ).action_notify_unsuccessful()
        self.alternative_po_ids.filtered(
            lambda po: po.state in ['draft', 'sent', 'to approve']
                       and po.id not in self.po_ids.ids).button_cancel()
        return self._action_done()

    def action_keep_alternative_notify(self):
        """keeping the POs as it is and informing the vendor about
        unsuccessful"""
        self.alternative_po_ids.filtered(
            lambda po: po.state in ['draft', 'sent', 'to approve']
                       and po.id not in self.po_ids.ids
        ).action_notify_unsuccessful()
        return self._action_done()
