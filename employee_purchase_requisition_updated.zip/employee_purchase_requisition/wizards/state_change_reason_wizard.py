# -*- coding: utf-8 -*-
from odoo import models, fields


class StateChangeReasonWizard(models.TransientModel):
    """wizard to enter the reason for changing the states"""
    _name = 'state.change.reason.wizard'
    _description = 'State Change Reason Wizard'

    state_to_change = fields.Selection(
        [('new', 'New'),
         ('waiting_department_approval', 'Waiting Department Approval'),
         ('waiting_head_approval', 'Waiting Head Approval'),
         ('approved', 'Approved'),
         ('rfq_created', 'RFQ Created'),
         ('rfq_sent', 'RFQ Sent'),
         ('purchase_order_created', 'Purchase Order Created'),
         ('received', 'Received'),
         ('cancelled', 'Cancelled')],
        default='new')
    previous_state = fields.Selection(
        [('new', 'New'),
         ('waiting_department_approval', 'Waiting Department Approval'),
         ('waiting_head_approval', 'Waiting Head Approval'),
         ('approved', 'Approved'),
         ('rfq_created', 'RFQ Created'),
         ('rfq_sent', 'RFQ Sent'),
         ('purchase_order_created', 'Purchase Order Created'),
         ('received', 'Received'),
         ('cancelled', 'Cancelled')],
        default='new')
    requisition_id = fields.Many2one('employee.purchase.requisition',
                                     'Requisition')
    user_id = fields.Many2one('res.users', 'User',
                              default=lambda self: self.env.user)
    reason = fields.Char('Reason', required=True)
    change_date = fields.Datetime('Date',
                                  default=lambda x: fields.Datetime.now())

    def action_change_state(self):
        """change the state and add the reason to requisition along with
        clearing the existing details fo the heads"""
        if self.state_to_change == 'new':
            self.requisition_id.sudo().write({
                'state': 'new',
                'confirm_id': False,
                'confirmed_date': False,
                'manager_id': False,
                'department_approval_date': False,
                'requisition_head_id': False,
                'approval_date': False,
                'rejected_user_id': False,
                'reject_date': False,
            })
        elif self.state_to_change == 'waiting_department_approval':
            self.requisition_id.sudo().write({
                'state': 'waiting_department_approval',
                'manager_id': False,
                'department_approval_date': False,
                'requisition_head_id': False,
                'approval_date': False,
                'rejected_user_id': False,
                'reject_date': False,
            })
        elif self.state_to_change == 'waiting_head_approval':
            self.requisition_id.sudo().write({
                'state': 'waiting_head_approval',
                'requisition_head_id': False,
                'approval_date': False,
                'rejected_user_id': False,
                'reject_date': False,
            })
        elif self.state_to_change == 'approved':
            self.requisition_id.sudo().write({
                'state': 'approved',
                'rejected_user_id': False,
                'reject_date': False,
            })
        elif self.state_to_change == 'rfq_created':
            self.requisition_id.sudo().write({
                'state': 'rfq_created'
            })
        elif self.state_to_change == 'rfq_sent':
            self.requisition_id.sudo().write({
                'state': 'rfq_sent'
            })
        elif self.state_to_change == 'purchase_order_created':
            self.requisition_id.sudo().write({
                'state': 'purchase_order_created'
            })
        self.requisition_id.sudo().write({
            'state_change_reason_ids': [fields.Command.create({
                'user_id': self.user_id.id,
                'change_date': self.change_date,
                'state_to_change': self.state_to_change,
                'previous_state': self.previous_state,
                'reason': self.reason,
            })]
        })
