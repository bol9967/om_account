# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
#############################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2023-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Vishnu P(<https://www.cybrosys.com>)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
#############################################################################

{
    'name': 'Employee Purchase Requisition',
    'version': '17.0.1.0.1',
    'category': 'Purchases',
    'summary': 'Employee Purchase Requisition',
    'description': 'Employee Purchase Requisition',
    'author': 'Cybrosys Techno Solutions',
    'company': 'Cybrosys Techno Solutions',
    'maintainer': 'Cybrosys Techno Solutions',
    'images': ['static/description/banner.png'],
    'website': 'https://www.cybrosys.com',
    'depends': ['base', 'hr', 'purchase_requisition', 'sale_purchase_stock', 'mrp', 'company_contacts_extra'],
    'data': [
        'security/security_access.xml',
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        # 'data/purchase_unsuccessful_mail_template.xml',
        'data/material_availability_notification_email_template.xml',
        'views/purchase_requisition.xml',
        'views/menu.xml',
        'views/hr_employee_view.xml',
        'views/hr_department_view.xml',
        'views/purchase_order_view.xml',
        'views/stock_picking_view.xml',
        'views/action_print_requisition.xml',
        'views/product_views.xml',
        'views/sale_order_views.xml',
        'views/mrp_production_views.xml',
        'wizards/requisition_confirm_wizard.xml',
        'wizards/purchase_requisition_alternative_warning.xml',
        'wizards/state_change_reason_wizard_views.xml',
        'report/purchase_requisition_template.xml',
        'report/purchase_requisition_report.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'employee_purchase_requisition/static/src/css/employee_purchase_requisition.css',
        ]
    },
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
