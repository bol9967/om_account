# -*- coding: utf-8 -*-
from odoo import models, api


class StockRule(models.Model):
    """stock rule inheritance for breaking the creation of RFQ, instead create
    purchase requisition based on product configuration"""
    _inherit = 'stock.rule'

    def _can_create_purchase_requisition(self, procurement):
        return (
                procurement[1].action == 'buy'
                and procurement[0].product_id.purchase_requisition
        )

    def purchase_requisition_data(self, origin, values):
        """Purchase requisition values to be created"""
        group = self.group_propagation_option
        group_id = ((group == 'fixed' and self.group_id.id)
                    or (group == 'propagate' and values[
                    'group_id'].id) or False)
        employee_id = self.env.user.employee_id or self.env[
            'hr.employee'].sudo().search([
            ('company_id', '=', self.env.company.id)
        ], limit=1)
        return {
            'origin': origin,
            'company_id': values['company_id'].id,
            'group_id': group_id or False,
            'employee_id': employee_id.id,
            'warehouse_id': employee_id.department_id and employee_id.department_id.warehouse_id and employee_id.department_id.warehouse_id.id,
            'user_id': self.env.context.get('uid') or self.env.user.id,
            'confirm_id': self.env.context.get('uid') or self.env.user.id,
            'requisition_type': 'in_direct',
        }

    def _prepare_requisition_line_data(self, requisition, procurement):
        po_qty = procurement.product_uom._compute_quantity(
            procurement.product_qty, procurement.product_id.uom_po_id)
        existing_requisition_line = requisition.requisition_order_ids.filtered(
            lambda x: x.product_id == procurement.product_id)
        if existing_requisition_line:
            existing_requisition_line[0].sudo().write({
                'quantity': existing_requisition_line[0].quantity + po_qty,
                'move_dest_ids': existing_requisition_line.move_dest_ids | procurement.values.get(
                    'move_dest_ids', self.env['stock.move']),
                'orderpoint_id': procurement.values.get('orderpoint_id', False)
                                 and procurement.values.get('orderpoint_id').id,
            })
            return False
        return {
            'requisition_type': 'purchase_order',
            'product_id': procurement.product_id.id,
            'description': procurement.product_id.name,
            'quantity': po_qty,
            'uom': procurement.product_id.uom_po_id.id,
            'requisition_product_id': requisition.id,
            'move_dest_ids': [
                (4, x.id) for x in procurement.values.get('move_dest_ids', [])
            ],
            'orderpoint_id': procurement.values.get('orderpoint_id', False)
                             and procurement.values.get('orderpoint_id').id,
        }

    def _create_purchase_requisition(self, procurement):
        ctx = self.env.context
        procure = procurement[0]
        rule = procurement[1]
        purchase_requisition = self.env[
            'employee.purchase.requisition']
        purchase_requisition_line = self.env['requisition.order']
        group = self.group_propagation_option
        group_id = ((group == 'fixed' and self.group_id.id)
                    or (group == 'propagate' and procure.values[
                    'group_id'].id) or False)
        domain = [
            ('state', '=', 'new'),
            ('company_id', '=', procure.values['company_id'].id),
            ('requisition_type', '=', 'in_direct')
        ]
        domain += ['|', ('user_id', '=', ctx.get('uid')),
                   ('confirm_id', '=', ctx.get('uid'))]
        if group_id:
            domain += [('group_id', '=', group_id)]
        requisition = purchase_requisition.sudo().search(domain)
        if not requisition:
            requisition_data = rule.purchase_requisition_data(procure.origin,
                                                              procure.values)
            requisition = purchase_requisition.sudo().create(requisition_data)
        else:
            if (not requisition.origin or procure.origin
                    not in requisition.origin.split(", ") and
                    procure.origin != '/'):
                if requisition.origin:
                    if procure.origin:
                        requisition.write({
                            'origin': requisition.origin + ", " + procure.origin
                        })
                else:
                    requisition.write({
                        'origin': procure.origin
                    })
        if procure.values.get('group_id', False) and procure.values[
            'group_id'].sale_id:
            procure.values['group_id'].sale_id.requisition_id = requisition.id
        elif procure.values.get('group_id', False) and procure.values[
            'group_id'].mrp_production_ids:
            procure.values[
                'group_id'].mrp_production_ids.requisition_id = requisition.id
        requisition_line_data = rule._prepare_requisition_line_data(requisition,
                                                                    procure)
        if requisition_line_data:
            purchase_requisition_line.sudo().create(requisition_line_data)

    @api.model
    def _run_buy(self, procurements):
        """Supering function to break the creation of rfq and to create
        purchase requisition based on product configuration"""
        data_to_pop = []
        for i, procurement in enumerate(procurements):
            if self._can_create_purchase_requisition(procurement):
                self._create_purchase_requisition(procurement)
                data_to_pop.append(i)
        if data_to_pop:
            data_to_pop.reverse()
            for data in data_to_pop:
                procurements.pop(data)
        if not procurements:
            return
        return super(StockRule, self)._run_buy(procurements)
