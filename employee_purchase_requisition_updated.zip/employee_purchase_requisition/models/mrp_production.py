# -*- coding: utf-8 -*-
from odoo import models, fields


class MrpProduction(models.Model):
    """Purchase requisition related to Manufacturing orders on MRP"""
    _inherit = 'mrp.production'

    requisition_id = fields.Many2one('employee.purchase.requisition',
                                     'Purchase Requisition', copy=False)
    requisition_count = fields.Integer('Requisition Count',
                                       compute='_compute_requisition_count')

    def _compute_requisition_count(self):
        for order in self:
            order.requisition_count = self.env[
                'employee.purchase.requisition'].search_count([
                ('id', '=', order.requisition_id.id)
            ])

    def action_get_purchase_requisition(self):
        """Related Purchase requisitions"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase Requisitions',
            'view_mode': 'tree,form',
            'res_model': 'employee.purchase.requisition',
            'domain': [('id', '=', self.requisition_id.id)],
        }
