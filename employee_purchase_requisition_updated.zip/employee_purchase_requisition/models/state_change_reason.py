# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class StateChangeReason(models.Model):
    """State change reason related to each requisitions"""
    _name = 'state.change.reason'
    _description = 'State Change Reason'

    state_to_change = fields.Selection(
        [('new', 'New'),
         ('waiting_department_approval', 'Waiting Department Approval'),
         ('waiting_head_approval', 'Waiting Head Approval'),
         ('approved', 'Approved'),
         ('rfq_created', 'RFQ Created'),
         ('rfq_sent', 'RFQ Sent'),
         ('purchase_order_created', 'Purchase Order Created'),
         ('received', 'Received'),
         ('cancelled', 'Cancelled')],
        default='new')
    previous_state = fields.Selection(
        [('new', 'New'),
         ('waiting_department_approval', 'Waiting Department Approval'),
         ('waiting_head_approval', 'Waiting Head Approval'),
         ('approved', 'Approved'),
         ('rfq_created', 'RFQ Created'),
         ('rfq_sent', 'RFQ Sent'),
         ('purchase_order_created', 'Purchase Order Created'),
         ('received', 'Received'),
         ('cancelled', 'Cancelled')],
        default='new')
    requisition_id = fields.Many2one('employee.purchase.requisition',
                                     'Requisition')
    user_id = fields.Many2one('res.users', 'User')
    reason = fields.Char('Reason', required=True)
    change_date = fields.Datetime('Date',
                                  default=lambda x: fields.Datetime.now())
