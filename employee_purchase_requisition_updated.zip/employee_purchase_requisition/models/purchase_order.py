# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
#############################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2023-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Vishnu P(<https://www.cybrosys.com>)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
#############################################################################
""" add field requisition_order in purchase order"""
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
from odoo.tools import float_compare, float_is_zero


class PurchaseOrder(models.Model):
    """ inherit purchase.order model """

    _inherit = 'purchase.order'

    requisition_order = fields.Char(string='Requisition Order',
                                    help='Requisition Order')
    requisition_order_ids = fields.Many2many('employee.purchase.requisition',
                                             string='Purchase Requisition',
                                             copy=False)

    @api.model
    def create(self, values):
        """inheriting for changing the sequence for RFQ"""
        if not values.get('order_line', False):
            raise ValidationError(_('You have to add atleast one Order Line'))
        res = super(PurchaseOrder, self).create(values)
        if res and res.state == 'draft':
            sequence_prefix = self.with_company(
                res.company_id or self.default_get(['company_id'])[
                    'company_id']).env['ir.sequence'].search([
                ('code', '=', 'purchase.order')
            ], limit=1).prefix
            res.name = res.name.replace(sequence_prefix, 'RFQ')
        return res

    def write(self, vals):
        """inheriting to check whether an order line is added or not"""
        res = super(PurchaseOrder, self).write(vals)
        for order in self:
            if not order.order_line:
                raise ValidationError(
                    _('You have to add atleast one Order Line'))
        return res

    def _get_sale_orders(self):
        return super(PurchaseOrder,
                     self)._get_sale_orders() | self.order_line.destination_move_ids.group_id.sale_id

    def action_notify_unsuccessful(self):
        """notifying vendors about the unsuccessfulness of the purchase order"""
        template = self.env.ref(
            'employee_purchase_requisition.purchase_unsuccessful_email_template')
        for order in self:
            if template and order.partner_id.email and order.id:
                template.send_mail(
                    order.id, force_send=True,
                    email_layout_xmlid='mail.mail_notification_layout_with_responsible_signature',
                    email_values={
                        'email_to': order.partner_id.email,
                        'recipient_ids': []})

    def button_confirm(self):
        """button confirm inheriting for changing the related PR state and also
         for changing the sequence for Purchase order"""
        if self.order_line.filtered(lambda x: x.product_qty == 0.0) or (
                self.has_alternatives and not self.order_line.filtered(
                lambda x: x.rfq_selected)):
            raise ValidationError(_('It is not possible to confirm a purchase '
                                    'order with zero quantity Order lines or '
                                    'without any selected order lines if '
                                    'Purchase has Alternatives'))
        res = super(PurchaseOrder, self).button_confirm()
        if self.state in ('purchase', 'done'):
            sequence_prefix = self.with_company(
                self.company_id or self.default_get(['company_id'])[
                    'company_id']).env['ir.sequence'].search([
                ('code', '=', 'purchase.order')
            ], limit=1).prefix
            self.name = self.name.replace('RFQ', sequence_prefix)
        ## below lines are commented as this will delete the lines in call
        ## off PO and to restrict this case, the below lines are updated and
        ## added on the purchase_order.py file of purchase_contract module
        # if self.requisition_order_ids or self.has_alternatives:
        #     self.order_line.filtered(lambda x: not x.rfq_selected).unlink()
        #     if self.state in (
        #     'purchase', 'done') and self.requisition_order_ids:
        #         self.requisition_order_ids.sudo().write({
        #             'state': 'purchase_order_created',
        #         })
        return res


class PurchaseOrderLine(models.Model):
    """ inherit purchase.order.line model """
    _inherit = 'purchase.order.line'

    destination_move_ids = fields.Many2many(
        'stock.move', string='Destination Moves', copy=False,
        help='Field helps to identify the destination moves to be assigned '
             'while validation an incoming moves which is only based for '
             'requisition related incoming moves (related to purchase order '
             'which is related to requisition)')
    requisition_line_ids = fields.Many2many('requisition.order',
                                            string='Requisition Lines',
                                            copy=False)
    line_number = fields.Integer('Line Number', compute='_compute_line_number')
    rfq_selected = fields.Boolean('Selected', readonly=True, copy=False)
    rfq_cleared = fields.Boolean('Cleared', readonly=True, copy=False)

    @api.depends('sequence', 'order_id')
    def _compute_line_number(self):
        for order in self.mapped('order_id'):
            line_number = 1
            for line in order.order_line:
                if line.display_type:
                    line.line_number = line_number
                    line_number += 0
                else:
                    line.line_number = line_number
                    line_number += 1

    @api.depends('product_qty', 'product_uom', 'company_id')
    def _compute_price_unit_and_date_planned_and_name(self):
        super(PurchaseOrderLine,
              self)._compute_price_unit_and_date_planned_and_name()
        for line in self:
            if line.requisition_line_ids:
                line.price_unit = 0.0

    def _prepare_stock_move_vals(self, picking, price_unit, product_uom_qty,
                                 product_uom):
        res = super(PurchaseOrderLine, self)._prepare_stock_move_vals(
            picking, price_unit, product_uom_qty, product_uom)
        res.update({
            'move_dest_ids': [(4, x.id) for x in
                              self.move_dest_ids | self.destination_move_ids]
        })
        return res

    def _prepare_stock_moves(self, picking):
        """ Prepare the stock moves data for one order line. This function
        returns a list of dictionary ready to be used in stock.move's create()
        """
        self.ensure_one()
        res = []
        if self.product_id.type not in ['product', 'consu']:
            return res
        price_unit = self._get_stock_move_price_unit()
        qty = self._get_qty_procurement()
        move_dests = self.move_dest_ids
        if self.destination_move_ids:
            move_dests |= self.destination_move_ids
        if not move_dests:
            move_dests = self.move_ids.move_dest_ids.filtered(
                lambda m: m.state != 'cancel' and not
                m.location_dest_id.usage == 'supplier')
        if not move_dests:
            qty_to_attach = 0
            qty_to_push = self.product_qty - qty
        else:
            move_dests_initial_demand = self.product_id.uom_id._compute_quantity(
                sum(move_dests.filtered(
                    lambda m: m.state != 'cancel' and
                              not m.location_dest_id.usage == 'supplier'
                ).mapped('product_qty')),
                self.product_uom, rounding_method='HALF-UP')
            qty_to_attach = move_dests_initial_demand - qty
            qty_to_push = self.product_qty - move_dests_initial_demand

        if float_compare(qty_to_attach, 0.0,
                         precision_rounding=self.product_uom.rounding) > 0:
            product_uom_qty, product_uom = self.product_uom._adjust_uom_quantities(
                qty_to_attach, self.product_id.uom_id)
            res.append(self._prepare_stock_move_vals(picking, price_unit,
                                                     product_uom_qty,
                                                     product_uom))
        if not float_is_zero(qty_to_push,
                             precision_rounding=self.product_uom.rounding):
            product_uom_qty, product_uom = self.product_uom._adjust_uom_quantities(
                qty_to_push, self.product_id.uom_id)
            extra_move_vals = self._prepare_stock_move_vals(picking, price_unit,
                                                            product_uom_qty,
                                                            product_uom)
            extra_move_vals['move_dest_ids'] = False  # don't attach
            res.append(extra_move_vals)
        if self.requisition_line_ids and self.rfq_selected:
            return res
        elif not self.requisition_line_ids and not self.order_id.has_alternatives:
            return res
        elif self.order_id.has_alternatives and self.rfq_selected:
            return res
        return []

    def action_choose(self):
        """updating the action choose to not clear the quantity and price"""
        order_lines = (self.order_id | self.order_id.alternative_po_ids).mapped(
            'order_line')
        order_lines = order_lines.filtered(
            lambda
                l: l.product_qty and l.product_id.id in
                   self.product_id.ids and l.id not in self.ids)
        self.rfq_selected = True
        order_lines.rfq_cleared = True
        if not order_lines:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _("Nothing to clear"),
                    'message': _("There are no quantities to clear."),
                    'sticky': False,
                }
            }
        return

    @api.ondelete(at_uninstall=False)
    def _unlink_except_purchase_or_done(self):
        for line in self:
            check = False
            if line.requisition_line_ids and line.rfq_selected:
                check = True
            elif (not line.requisition_line_ids and
                  not line.order_id.has_alternatives):
                check = True
            if (line.order_id.state in ['purchase', 'done'] and not
            line.is_shipping and check):
                state_description = {state_desc[0]: state_desc[1] for state_desc
                                     in self._fields[
                                         'state']._description_selection(
                        self.env)}
                raise UserError(
                    _('Cannot delete a purchase order line which is in state \'%s\'.') % (
                        state_description.get(line.state),))
