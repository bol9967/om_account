# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class SaleOrder(models.Model):
    """Purchase requisition related to sale orders on MRP"""
    _inherit = 'sale.order'

    requisition_id = fields.Many2one('employee.purchase.requisition',
                                     'Purchase Requisition', copy=False)
    requisition_count = fields.Integer('Requisition Count',
                                       compute='_compute_requisition_count')

    def _compute_requisition_count(self):
        for order in self:
            order.requisition_count = self.env[
                'employee.purchase.requisition'].search_count([
                ('id', '=', order.requisition_id.id)
            ])

    def _get_purchase_orders(self):
        purchase_order_ids = self.env['purchase.order.line'].sudo().search([
            ('destination_move_ids.group_id.sale_id', '=', self.id)
        ]).order_id
        return super(SaleOrder, self)._get_purchase_orders() | purchase_order_ids

    @api.model
    def create(self, values):
        """create method inheriting to set the correct sequence for quotation
         and sale order"""
        if not values.get('order_line', False):
            raise ValidationError(_('You have to add atleast one Order Line'))
        res = super(SaleOrder, self).create(values)
        if res and res.state == 'draft':
            sequence_prefix = self.with_company(
                res.company_id or self.default_get(['company_id'])[
                    'company_id']).env['ir.sequence'].search([
                ('code', '=', 'sale.order')
            ], limit=1).prefix
            res.name = res.name.replace(sequence_prefix, 'QUO')
        return res

    def write(self, vals):
        """write function inheriting for adding validations to have order
         line"""
        res = super(SaleOrder, self).write(vals)
        for order in self:
            if not order.order_line:
                raise ValidationError(
                    _('You have to add atleast one Order Line'))
        return res

    def action_confirm(self):
        """action confirm inheriting for setting the correct sequence for
        sale orders"""
        res = super(SaleOrder, self).action_confirm()
        if self.state in ('sale', 'done'):
            sequence_prefix = self.with_company(
                self.company_id or self.default_get(['company_id'])[
                    'company_id']).env['ir.sequence'].search([
                ('code', '=', 'sale.order')
            ], limit=1).prefix
            self.name = self.name.replace('QUO', sequence_prefix)
        return res

    def action_get_purchase_requisition(self):
        """Related Purchase requisitions"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase Requisitions',
            'view_mode': 'tree,form',
            'res_model': 'employee.purchase.requisition',
            'domain': [('id', '=', self.requisition_id.id)],
        }


class SaleOrderLine(models.Model):
    """Purchase requisition related to sale orders on MRP"""
    _inherit = 'sale.order.line'

    line_number = fields.Integer('Line Number', compute='_compute_line_number')

    @api.depends('sequence', 'order_id')
    def _compute_line_number(self):
        for order in self.mapped('order_id'):
            line_number = 1
            for line in order.order_line:
                if line.display_type:
                    line.line_number = line_number
                    line_number += 0
                else:
                    line.line_number = line_number
                    line_number += 1
