# -*- coding: utf-8 -*-
from odoo import models, fields


class ProductTemplate(models.Model):
    """Purchase requisition creation boolean"""
    _inherit = 'product.template'

    purchase_requisition = fields.Boolean(company_dependent=True, default=True)
