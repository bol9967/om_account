# -*- coding: utf-8 -*-
from odoo import models, fields


class StockMove(models.Model):
    """Auto reserving of product to be delivered based on the purchase
    reception"""
    _inherit = 'stock.move'

    created_requisition_order = fields.Many2one('requisition.order',
                                                'Created Purchase Requisition line',
                                                ondelete='set null',
                                                readonly=True, copy=False,
                                                index=True)

    def _action_done(self, cancel_backorder=False):
        res = super(StockMove, self)._action_done(cancel_backorder)
        template = self.env.ref(
            'employee_purchase_requisition.material_availability_notification_email_template')
        for move in self:
            if move.purchase_line_id and move.purchase_line_id.destination_move_ids:
                continue
            if move.location_dest_id.usage == 'internal':
                move_qty = move.quantity
                moves_to_assign = self.env['stock.move'].sudo().search(
                    [('company_id', 'in', [move.company_id.id, False]),
                     ('location_id', '=', move.location_dest_id.id),
                     ('product_id', '=', move.product_id.id),
                     ('state', 'in',
                      ['confirmed', 'partially_available', 'waiting']),
                     ('product_uom_qty', '!=', 0.0),
                     ('reservation_date', '<=', fields.Date.today()),
                     ], limit=None,
                    order='reservation_date, priority desc, date asc, id asc')
                for move_to_assign in moves_to_assign:
                    email_to_notify = False
                    user_to_notify = ''
                    related_record = ''
                    if move_to_assign.sale_line_id:
                        related_record = move_to_assign.sale_line_id.order_id.name
                    elif move_to_assign.raw_material_production_id:
                        related_record = move_to_assign.raw_material_production_id.name
                    if (move_to_assign.picking_id and
                            move_to_assign.picking_id.user_id and
                            move_to_assign.picking_id.user_id.partner_id.email):
                        email_to_notify = move_to_assign.picking_id.user_id.partner_id.email
                        user_to_notify = move_to_assign.picking_id.user_id.partner_id.name
                    elif (move_to_assign.sale_line_id and
                          move_to_assign.sale_line_id.salesman_id and
                          move_to_assign.sale_line_id.salesman_id.partner_id.email):
                        email_to_notify = move_to_assign.sale_line_id.salesman_id.partner_id.email
                        user_to_notify = move_to_assign.sale_line_id.salesman_id.partner_id.name
                    elif move_to_assign.create_uid.partner_id.email:
                        email_to_notify = move_to_assign.create_uid.partner_id.email
                        user_to_notify = move_to_assign.create_uid.partner_id.name
                    if not move_qty <= 0.0:
                        if email_to_notify:
                            template.with_context(
                                user_to_notify=user_to_notify,
                                related_record=related_record).send_mail(
                                move_to_assign.id, force_send=True,
                                email_layout_xmlid='mail.mail_notification_layout_with_responsible_signature',
                                email_values={
                                    'email_to': email_to_notify,
                                    'recipient_ids': []})
                        else:
                            continue
                    else:
                        break
                    move_qty -= move_to_assign.product_uom_qty
        return res
