# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
#############################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2023-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Vishnu P(<https://www.cybrosys.com>)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
#############################################################################
""" Purchase Requisition model"""
from collections import defaultdict
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_is_zero


class PurchaseRequisition(models.Model):
    """ Model for storing purchase requisition """
    _name = 'employee.purchase.requisition'
    _description = 'Purchase Requisition'
    _inherit = "mail.thread", "mail.activity.mixin"

    name = fields.Char(string="Reference No", copy=False, readonly=True)
    employee_id = fields.Many2one('hr.employee', string='Employee',
                                  required=True, help='Employee', default=lambda
            self: self.env.user.employee_id)
    dept_id = fields.Many2one('hr.department', string='Department',
                              related='employee_id.department_id', store=True,
                              help='Department')
    user_id = fields.Many2one('res.users', string='Requisition Responsible',
                              required=True, default=lambda self: self.env.user,
                              help='Requisition responsible user')
    requisition_date = fields.Date(string="Requisition Date",
                                   default=lambda self: fields.Date.today(),
                                   help='Date of Requisition')
    receive_date = fields.Date(string="Received Date", readonly=True,
                               help='Receive Date', copy=False, )
    requisition_deadline = fields.Date(string="Requisition Deadline",
                                       copy=False,
                                       help="End date of Purchase requisition")
    company_id = fields.Many2one('res.company', string='Company',
                                 default=lambda self: self.env.company,
                                 help='Company')
    requisition_order_ids = fields.One2many('requisition.order',
                                            'requisition_product_id',
                                            copy=True)
    confirm_id = fields.Many2one('res.users', string='Confirmed By',
                                 default=lambda self: self.env.uid,
                                 readonly=True, copy=False,
                                 help='User who Confirmed the requisition.')
    manager_id = fields.Many2one('res.users', string='Department Manager',
                                 readonly=True, help='Department Manager',
                                 copy=False, )
    requisition_head_id = fields.Many2one('res.users', string='Approved By',
                                          readonly=True, copy=False,
                                          help='User who approved the requisition.')
    rejected_user_id = fields.Many2one('res.users', string='Rejected By',
                                       readonly=True, copy=False,
                                       help='user who rejected the requisition')
    confirmed_date = fields.Date(string='Confirmed Date', readonly=True,
                                 copy=False,
                                 help='Date of Requisition Confirmation')
    department_approval_date = fields.Date(string='Department Approval Date',
                                           readonly=True, copy=False,
                                           help='Department Approval Date')
    approval_date = fields.Date(string='Approved Date', readonly=True,
                                copy=False,
                                help='Requisition Approval Date')
    reject_date = fields.Date(string='Rejection Date', readonly=True,
                              copy=False,
                              help='Requisition Rejected Date')
    source_location_id = fields.Many2one('stock.location',
                                         string='Source Location',
                                         help='Source location of requisition.')
    destination_location_id = fields.Many2one('stock.location',
                                              string="Destination Location",
                                              help='Destination location of '
                                                   'requisition.')
    delivery_type_id = fields.Many2one('stock.picking.type',
                                       string='Delivery To',
                                       help='Type of Delivery.')
    internal_picking_id = fields.Many2one('stock.picking.type',
                                          string="Internal Picking")
    requisition_description = fields.Text(string="Reason For Requisition",
                                          copy=False)
    purchase_count = fields.Integer(string='Purchase Count',
                                    help='Purchase Count',
                                    compute='_compute_purchase_count')
    internal_transfer_count = fields.Integer(string='Internal Transfer count',
                                             help='Internal Transfer count',
                                             compute='_compute_internal_transfer_count')
    state = fields.Selection(
        [('new', 'New'),
         ('waiting_department_approval', 'Waiting Department Approval'),
         ('waiting_head_approval', 'Waiting Head Approval'),
         ('approved', 'Approved'),
         ('rfq_created', 'RFQ Created'),
         ('rfq_sent', 'RFQ Sent'),
         ('purchase_order_created', 'Purchase Order Created'),
         ('received', 'Received'),
         ('cancelled', 'Cancelled')],
        default='new', copy=False, tracking=True)
    origin = fields.Char('Source Document')
    group_id = fields.Many2one('procurement.group', 'Procurement Group',
                               copy=False, index=True)
    partner_ids = fields.Many2many('res.partner', string='Suppliers')
    partner_email_ids = fields.Many2many(
        'res.partner',
        relation='employee_purchase_requisition_partner_email_rel',
        string='Supplier Emails')
    warehouse_id = fields.Many2one('stock.warehouse', 'Warehouse')
    requisition_type = fields.Selection(
        [('direct', 'Direct'), ('in_direct', 'In Direct')], 'Requisition Type',
        default='direct', copy=False, )
    rfq_count = fields.Integer(string='RFQ Count',
                               help='RFQ Count',
                               compute='_compute_rfq_count')
    field_edit_access = fields.Boolean(
        'Field Edit Access', precompute=True, store=True,
        compute='_compute_access_and_button_visibility')
    manager_access = fields.Boolean(
        'Manager Access',
        compute='_compute_access_visibility_of_button')
    rfq_price_updated = fields.Boolean('Price Updated',
                                       compute='_compute_rfq_price_updated')
    has_sent_rfq = fields.Boolean('Has Sent RFQ',
                                  precompute=True, store=True,
                                  compute='_compute_access_visibility_of_button')
    state_change_reason_ids = fields.One2many('state.change.reason',
                                              'requisition_id',
                                              'State Change Details')
    has_state_change_details = fields.Boolean(
        'Has State Change Details',
        compute='_compute_access_visibility_of_button')

    def _compute_internal_transfer_count(self):
        self.internal_transfer_count = self.env['stock.picking'].search_count([
            ('requisition_order_id', '=', self.id)])

    def _compute_purchase_count(self):
        self.purchase_count = self.env['purchase.order'].search_count([
            ('requisition_order_ids', '=', self.id),
            ('company_id', '=', self.company_id.id),
            ('state', 'in', ('purchase', 'done'))])

    def _compute_rfq_count(self):
        self.rfq_count = self.env['purchase.order'].search_count([
            ('requisition_order_ids', '=', self.id),
            ('company_id', '=', self.company_id.id),
            ('state', 'in', ('draft', 'sent'))])

    @api.depends('user_id')
    def _compute_access_and_button_visibility(self):
        for requisition in self:
            user = self.env.user
            sent_rfq_count = self.env['purchase.order'].search_count([
                ('requisition_order_ids', '=', requisition.id),
                ('company_id', '=', requisition.company_id.id),
                ('state', '=', 'sent')])
            requisition.field_edit_access = False
            requisition.manager_access = False
            requisition.has_sent_rfq = False
            requisition.has_state_change_details = False
            if user.has_group('purchase.group_purchase_user'):
                requisition.field_edit_access = True
            if user.has_group(
                    'employee_purchase_requisition.employee_requisition_manager'
            ):
                requisition.manager_access = True
            if sent_rfq_count:
                requisition.has_sent_rfq = True
            if requisition.state_change_reason_ids:
                requisition.has_state_change_details = True

    def _compute_access_visibility_of_button(self):
        for requisition in self:
            user = self.env.user
            sent_rfq_count = self.env['purchase.order'].search_count([
                ('requisition_order_ids', '=', requisition.id),
                ('company_id', '=', requisition.company_id.id),
                ('state', '=', 'sent')])
            requisition.field_edit_access = False
            requisition.manager_access = False
            requisition.has_sent_rfq = False
            requisition.has_state_change_details = False
            if user.has_group('purchase.group_purchase_user'):
                requisition.field_edit_access = True
            if user.has_group(
                    'employee_purchase_requisition.employee_requisition_manager'
            ):
                requisition.manager_access = True
            if sent_rfq_count:
                requisition.has_sent_rfq = True
            if requisition.state_change_reason_ids:
                requisition.has_state_change_details = True

    def _compute_rfq_price_updated(self):
        for requisition in self:
            requisition.rfq_price_updated = False
            rfq_ids = self.env['purchase.order'].search([
                ('requisition_order_ids', '=', requisition.id),
                ('company_id', '=', requisition.company_id.id),
                ('state', 'in', ('draft', 'sent'))])
            if sum(rfq_ids.mapped('amount_total')) > 0.0:
                requisition.rfq_price_updated = True

    @api.onchange('employee_id', 'dept_id')
    def _onchange_employee_id(self):
        self.ensure_one()
        self.warehouse_id = self.employee_id.department_id.warehouse_id.id
        self.source_location_id = self.employee_id.department_id.department_location_id.id
        self.destination_location_id = self.employee_id.employee_location_id.id
        self.delivery_type_id = self.source_location_id.warehouse_id.in_type_id.id
        self.internal_picking_id = self.source_location_id.warehouse_id.int_type_id.id

    @api.model
    def create(self, vals):
        """generate purchase requisition sequence"""
        if not vals.get('requisition_order_ids', False):
            if vals.get('requisition_type', 'direct') != 'in_direct':
                raise ValidationError(_('You have to add atleast one '
                                        'Requisition line'))
        if vals.get('name', 'New') == 'New':
            if vals.get('requisition_type', False):
                if vals.get('requisition_type') == 'in_direct':
                    vals['name'] = self.env['ir.sequence'].next_by_code(
                        'employee.purchase.requisition.indirect') or 'New'
                else:
                    vals['name'] = self.env['ir.sequence'].next_by_code(
                        'employee.purchase.requisition') or 'New'
            else:
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'employee.purchase.requisition') or 'New'
        result = super(PurchaseRequisition, self).create(vals)
        return result

    def write(self, vals):
        """inheriting for checking the requisition line exist or not"""
        res = super(PurchaseRequisition, self).write(vals)
        for requisition in self:
            if not requisition.requisition_order_ids:
                raise ValidationError(
                    _('You have to add atleast one Requisition '
                      'line'))
        return res

    def action_confirm_requisition(self):
        """confirm purchase requisition"""
        if self.requisition_type == 'direct':
            locations = self.env['stock.location'].sudo().search([
                ('warehouse_id', '=', self.warehouse_id.id),
                ('company_id', '=', self.company_id.id),
                ('usage', '=', 'internal')
            ])
            forecasted_qty_by_loc = {}
            for loc in locations:
                product_ids = self.requisition_order_ids.mapped('product_id')
                products = self.env['product.product'].browse(
                    product_ids.ids).with_context(location=loc.id)
                for product in products:
                    if forecasted_qty_by_loc.get(product, False):
                        forecasted_qty_by_loc[product].append(product.free_qty)
                    else:
                        forecasted_qty_by_loc[product] = [product.free_qty]
            wizard_lines = []
            for line in self.requisition_order_ids:
                free_qty_in_stock = sum(forecasted_qty_by_loc[line.product_id])
                if not float_is_zero(free_qty_in_stock,
                                     precision_rounding=line.product_id.uom_po_id.rounding):
                    qty = 0.0
                    if line.quantity > free_qty_in_stock:
                        qty = abs(line.quantity - free_qty_in_stock)
                        wizard_lines.append({
                            'product_id': line.product_id.id,
                            'quantity': qty,
                            'uom_id': line.product_id.uom_po_id.id,
                            'requisition_type': 'purchase_order',
                            'exact_requisition_line_id': line.id,
                            'exact_requisition_id': line.requisition_product_id.id,
                            'message': '{} is to be purchased'.format(qty)
                        })
                        wizard_lines.append({
                            'product_id': line.product_id.id,
                            'quantity': free_qty_in_stock,
                            'uom_id': line.product_id.uom_po_id.id,
                            'requisition_type': 'pick_ticket',
                            'exact_requisition_id': line.requisition_product_id.id,
                            'message': '{} is to be picked from the stock'.format(
                                free_qty_in_stock)
                        })
                    else:
                        wizard_lines.append({
                            'product_id': line.product_id.id,
                            'quantity': qty,
                            'uom_id': line.product_id.uom_po_id.id,
                            'requisition_type': 'pick_ticket',
                            'exact_requisition_line_id': line.id,
                            'exact_requisition_id': line.requisition_product_id.id,
                            'message': '{} is to be picked from the stock'.format(
                                qty)
                        })
                else:
                    line.requisition_type = 'purchase_order'
            if wizard_lines:
                confirm_wizard = self.env[
                    'requisition.confirm.wizard'].sudo().create({
                    'requisition_id': self.id,
                    'requisition_line_ids': [fields.Command.create(wizard_line)
                                             for
                                             wizard_line
                                             in
                                             wizard_lines]
                })
                action = self.env['ir.actions.actions']._for_xml_id(
                    'employee_purchase_requisition.requisition_confirm_wizard_view_form_action')
                action['res_id'] = confirm_wizard.id
                return action
        self.write({'state': 'waiting_department_approval'})
        self.confirm_id = self.env.uid
        self.confirmed_date = fields.Date.today()
        return

    def action_department_approval(self):
        """approval from department"""
        self.write({'state': 'waiting_head_approval'})
        self.manager_id = self.env.uid
        self.department_approval_date = fields.Date.today()

    def action_department_cancel(self):
        """cancellation from department """
        self.write({'state': 'cancelled'})
        self.rejected_user_id = self.env.uid
        self.reject_date = fields.Date.today()

    def action_head_approval(self):
        """approval from department head"""
        self.write({'state': 'approved'})
        self.requisition_head_id = self.env.uid
        self.approval_date = fields.Date.today()

    def action_head_cancel(self):
        """cancellation from department head"""
        self.write({'state': 'cancelled'})
        self.rejected_user_id = self.env.uid
        self.reject_date = fields.Date.today()

    def _create_internal_transfers(self):
        for rec in self.requisition_order_ids.filtered(
                lambda x: x.requisition_type == 'internal_transfer'):
            self.env['stock.picking'].create({
                'location_id': self.source_location_id.id,
                'location_dest_id': self.destination_location_id.id,
                'picking_type_id': self.internal_picking_id.id,
                'requisition_order': self.name,
                'requisition_order_id': self.id,
                'move_ids_without_package': [fields.Command.create({
                    'name': rec.product_id.name,
                    'product_id': rec.product_id.id,
                    'product_uom': rec.product_id.uom_id,
                    'product_uom_qty': rec.quantity,
                    'location_id': self.source_location_id.id,
                    'location_dest_id': self.destination_location_id.id,
                })]
            })

    def _state_change(self):
        self.write({'state': 'rfq_created'})

    def action_create_purchase_order(self):
        """create purchase order and internal transfer"""
        purchase_requisitions = self.requisition_order_ids.filtered(
            lambda x: x.requisition_type in ('purchase_order', False))
        purchase_orders = self.env['purchase.order']
        if purchase_requisitions:
            for rec in self.partner_ids | self.partner_email_ids:
                check = True
                purchase_order = self.env['purchase.order'].sudo().search([
                    ('state', '=', 'draft'), ('partner_id', '=', rec.id),
                    ('company_id', '=', self.company_id.id)
                ], limit=1, order='id asc')
                if not purchase_order:
                    check = False
                else:
                    purchase_order.requisition_order = "{}, {}".format(
                        purchase_order.requisition_order, self.name) \
                        if purchase_order.requisition_order else self.name
                purchase_order.requisition_order_ids = [(4, self.id)]
                count = 0
                for res in purchase_requisitions:
                    existing_po_line = purchase_order.order_line.filtered(
                        lambda x: x.product_id == res.product_id) if check else \
                        self.env['purchase.order.line']
                    if existing_po_line:
                        qty = existing_po_line.product_uom._compute_quantity(
                            res.quantity, res.product_id.uom_po_id)
                        existing_po_line.sudo().write({
                            'product_qty': existing_po_line.product_qty + qty,
                            'destination_move_ids': [(4, x.id) for x in
                                                     res.move_dest_ids],
                            'requisition_line_ids': [(4, res.id)]
                        })
                        count += 1
                    else:
                        if not check and not purchase_order:
                            purchase_order = self.env[
                                'purchase.order'].sudo().create({
                                'partner_id': rec.id,
                                'requisition_order': self.name,
                                'requisition_order_ids': [(4, self.id)],
                                "order_line": [fields.Command.create({
                                    'product_id': res.product_id.id,
                                    'product_qty': res.quantity,
                                    'product_uom': res.product_id.uom_po_id.id,
                                    'destination_move_ids': [(4, x.id) for x in
                                                             res.move_dest_ids],
                                    'requisition_line_ids': [(4, res.id)]
                                })]
                            })
                        else:
                            purchase_order.sudo().write({
                                "order_line": [fields.Command.create({
                                    'product_id': res.product_id.id,
                                    'product_qty': res.quantity,
                                    'product_uom': res.product_id.uom_po_id.id,
                                    'destination_move_ids': [(4, x.id) for x in
                                                             res.move_dest_ids],
                                    'requisition_line_ids': [(4, res.id)]
                                })]})
                        count += 1
                purchase_orders |= purchase_order
        for purchase in purchase_orders:
            order_alternatives = purchase_orders - purchase
            purchase.alternative_po_ids |= order_alternatives
        self._create_internal_transfers()
        self._state_change()

    def action_receive(self):
        """receive purchase requisition"""
        self.write({'state': 'received'})
        self.receive_date = fields.Date.today()

    def get_purchase_order(self):
        """purchase order smart button view"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase Order',
            'view_mode': 'tree,form',
            'res_model': 'purchase.order',
            'domain': [('requisition_order_ids', '=', self.id),
                       ('company_id', '=', self.company_id.id),
                       ('state', 'in', ('purchase', 'done'))],
        }

    def get_rfq(self):
        """purchase order smart button view"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'RFQ',
            'view_mode': 'tree,form',
            'res_model': 'purchase.order',
            'domain': [('requisition_order_ids', '=', self.id),
                       ('company_id', '=', self.company_id.id),
                       ('state', 'in', ('draft', 'sent'))],
        }

    def get_internal_transfer(self):
        """internal transfer smart tab view"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Internal Transfers',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'domain': [('requisition_order_ids', '=', self.id),
                       ('company_id', '=', self.company_id.id)],
        }

    def action_print_report(self):
        """print purchase requisition report"""
        data = {
            'employee': self.employee_id.name,
            'records': self.read(),
            'order_ids': self.requisition_order_ids.read(),
        }
        return self.env.ref(
            'employee_purchase_requisition.action_report_purchase_requisition').report_action(
            self, data=data)

    def action_send_rfq(self):
        """action to send RFQ"""
        rfq_ids = self.env['purchase.order'].search(
            [('requisition_order_ids', '=', self.id),
             ('company_id', '=', self.company_id.id),
             ('state', '=', 'draft')])
        template_id = self.env.ref('purchase.email_template_edi_purchase')
        for rfq in rfq_ids:
            if template_id and rfq.partner_id.email:
                template_id.send_mail(rfq.id,
                                      force_send=True,
                                      email_layout_xmlid='mail.mail_notification_layout_with_responsible_signature',
                                      email_values={
                                          'email_to': rfq.partner_id.email,
                                          'recipient_ids': []})
                rfq.state = 'sent'
        self.state = 'rfq_sent'

    def action_compare_rfq(self):
        """action to compare RFQ"""
        purchase_orders = self.env['purchase.order'].search(
            [('requisition_order_ids', '=', self.id),
             ('company_id', '=', self.company_id.id),
             ('state', '=', 'sent')])
        if purchase_orders:
            ctx = dict(
                self.env.context,
                search_default_groupby_product=True,
                purchase_order_id=purchase_orders[0].id
            )
            view_id = self.env.ref(
                'purchase_requisition.purchase_order_line_compare_tree').id
            return {
                'name': _('Compare Order Lines'),
                'type': 'ir.actions.act_window',
                'view_mode': 'list',
                'res_model': 'purchase.order.line',
                'views': [(view_id, 'list')],
                'domain': [('order_id', 'in', purchase_orders.ids),
                           ('display_type', '=', False)],
                'context': ctx,
            }
        raise UserError(_('No related Purchase Orders with this '
                          'Requisition'))

    def action_draft(self):
        """set to draft along with the reason"""
        action = self.env['ir.actions.actions']._for_xml_id(
            'employee_purchase_requisition.state_change_reason_wizard_view_form_action')
        ctx = self.env.context.copy()
        ctx.update({
            'default_state_to_change': 'new',
            'default_previous_state': self.state,
            'default_requisition_id': self.id,
        })
        action['context'] = ctx
        return action

    def action_to_department_approval(self):
        """set to department approval along with the reason"""
        action = self.env['ir.actions.actions']._for_xml_id(
            'employee_purchase_requisition.state_change_reason_wizard_view_form_action')
        ctx = self.env.context.copy()
        ctx.update({
            'default_state_to_change': 'waiting_department_approval',
            'default_previous_state': self.state,
            'default_requisition_id': self.id,
        })
        action['context'] = ctx
        return action

    def action_to_head_approval(self):
        """set to head approval along with the reason"""
        action = self.env['ir.actions.actions']._for_xml_id(
            'employee_purchase_requisition.state_change_reason_wizard_view_form_action')
        ctx = self.env.context.copy()
        ctx.update({
            'default_state_to_change': 'waiting_head_approval',
            'default_previous_state': self.state,
            'default_requisition_id': self.id,
        })
        action['context'] = ctx
        return action

    def action_to_approved(self):
        """set to approved along with the reason"""
        action = self.env['ir.actions.actions']._for_xml_id(
            'employee_purchase_requisition.state_change_reason_wizard_view_form_action')
        ctx = self.env.context.copy()
        ctx.update({
            'default_state_to_change': 'approved',
            'default_previous_state': self.state,
            'default_requisition_id': self.id,
        })
        action['context'] = ctx
        return action

    def action_to_rfq_created(self):
        """set to RFQ created along with the reason"""
        action = self.env['ir.actions.actions']._for_xml_id(
            'employee_purchase_requisition.state_change_reason_wizard_view_form_action')
        ctx = self.env.context.copy()
        ctx.update({
            'default_state_to_change': 'rfq_created',
            'default_previous_state': self.state,
            'default_requisition_id': self.id,
        })
        action['context'] = ctx
        return action

    def action_to_rfq_sent(self):
        """set to RFQ sent along with the reason"""
        action = self.env['ir.actions.actions']._for_xml_id(
            'employee_purchase_requisition.state_change_reason_wizard_view_form_action')
        ctx = self.env.context.copy()
        ctx.update({
            'default_state_to_change': 'rfq_sent',
            'default_previous_state': self.state,
            'default_requisition_id': self.id,
        })
        action['context'] = ctx
        return action

    def action_to_purchase_created(self):
        """set to purchase created along with the reason"""
        action = self.env['ir.actions.actions']._for_xml_id(
            'employee_purchase_requisition.state_change_reason_wizard_view_form_action')
        ctx = self.env.context.copy()
        ctx.update({
            'default_state_to_change': 'purchase_order_created',
            'default_previous_state': self.state,
            'default_requisition_id': self.id,
        })
        action['context'] = ctx
        return action


class RequisitionProducts(models.Model):
    """Requisition details line"""
    _name = 'requisition.order'
    _description = 'Requisition order'

    requisition_product_id = fields.Many2one(
        'employee.purchase.requisition', help='Requisition product.',
        copy=False)
    state = fields.Selection(string='State',
                             related='requisition_product_id.state')
    requisition_type = fields.Selection(
        string='Requisition Type',
        selection=[
            ('purchase_order', 'Purchase Tender'),
            ('internal_transfer', 'Internal Transfer'),
            ('pick_ticket', 'Pick Ticket'),
        ], help='Type of requisition', copy=False)
    product_id = fields.Many2one('product.product', required=True,
                                 help='Product')
    description = fields.Text(
        string="Description",
        compute='_compute_name',
        store=True, readonly=False,
        precompute=True, help='Product Description')
    quantity = fields.Integer(string='Quantity', help='Quantity', default=1.0)
    uom = fields.Char(related='product_id.uom_po_id.name',
                      string='Unit of Measure', help='Product Uom')
    partner_id = fields.Many2one('res.partner', string='Vendor',
                                 help='Vendor for the requisition')
    move_dest_ids = fields.One2many('stock.move', 'created_requisition_order',
                                    string='Downstream Moves', copy=False)
    orderpoint_id = fields.Many2one('stock.warehouse.orderpoint', 'Orderpoint',
                                    copy=False)
    company_id = fields.Many2one(related='requisition_product_id.company_id')
    currency_id = fields.Many2one(related='company_id.currency_id')
    estimated_cost = fields.Monetary(currency_field='currency_id', default=0.0)
    date_request = fields.Date("Request Date", required=True,
                               default=fields.Date.context_today, copy=False)
    requisition_date = fields.Date(
        related='requisition_product_id.requisition_date', store=True)
    message = fields.Char('Requisition Message', copy=False)
    line_number = fields.Integer('Line Number', compute='_compute_line_number')

    @api.depends('product_id')
    def _compute_name(self):
        """compute product description"""
        for option in self:
            if not option.product_id:
                continue
            product_lang = option.product_id.with_context(
                lang=self.requisition_product_id.employee_id.lang)
            option.description = product_lang.get_product_multiline_description_sale()

    @api.depends('requisition_product_id')
    def _compute_line_number(self):
        for prl in self.mapped('requisition_product_id'):
            line_number = 1
            for line in prl.requisition_order_ids:
                line.line_number = line_number
                line_number += 1

    @api.onchange('requisition_type')
    def _onchange_product(self):
        """fetching product vendors"""
        vendors_list = []
        for data in self.product_id.seller_ids:
            vendors_list.append(data.partner_id.id)
        return {'domain': {'partner_id': [('id', 'in', vendors_list)]}}
